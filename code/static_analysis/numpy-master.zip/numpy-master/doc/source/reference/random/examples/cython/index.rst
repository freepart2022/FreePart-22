
.. _extending_cython_example:

Extending `numpy.random` via Cython
-----------------------------------


.. toctree::
    setup.py.rst
    extending.pyx
    extending_distributions.pyx
