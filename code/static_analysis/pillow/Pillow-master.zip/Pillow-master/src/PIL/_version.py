# Master version for Pillow
__version__ = "8.0.0.dev0"
